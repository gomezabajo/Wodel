package mutator.wodeltest.statistics;

import java.io.File;
import java.util.Map;
import java.util.TreeMap;

public class GenerateResultsTxt {
	
	private static final String projectPath = GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().substring(0, GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().lastIndexOf("/")).substring(0, GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().substring(0, GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().lastIndexOf("/")).lastIndexOf("/")).replace("file:/", "");
	private static final String projectName = projectPath.substring(projectPath.lastIndexOf("/") + 1, projectPath.length());
	private static final String outputPath = projectPath + "/data/out";
	
	
	private static void generateResultsTxt() {
		File outputFolder = new File(outputPath);
		Map<String, Map<String, Integer>> results = new TreeMap<String, Map<String, Integer>>();
		if (outputFolder.exists() && outputFolder.isDirectory() && outputFolder.listFiles().length > 0) {
			File[] chatbotFolders = outputFolder.listFiles();
			for (File chatbotFolder : chatbotFolders) {
				if (chatbotFolder.exists() && chatbotFolder.isDirectory()) {
					String chatbotName = chatbotFolder.getName();
					Map<String, Integer> chatbotResults = new TreeMap<String, Integer>();
					results.put(chatbotName, chatbotResults);
					for (File mutFolder : chatbotFolder.listFiles()) {
						if (mutFolder.exists() && mutFolder.isDirectory()) {
							String mutName = mutFolder.getName();
							int count = 0;
							for (File mutFile : mutFolder.listFiles()) {
								if (mutFile.exists() && mutFile.isFile()) {
									count++;
								}
							}
							chatbotResults.put(mutName, count);
						}
					}
				}
			}
		}
		
		int totalGeneratedMutants = 0;
		Map<String, Integer> byMutationOperator = new TreeMap<String, Integer>(); 
		for (String chatbotName : results.keySet()) {
			for (String mutName : results.get(chatbotName).keySet()) {
				totalGeneratedMutants += results.get(chatbotName).get(mutName);
				if (byMutationOperator.get(mutName) == null) {
					byMutationOperator.put(mutName, results.get(chatbotName).get(mutName));
				}
				else {
					byMutationOperator.put(mutName, byMutationOperator.get(mutName) + results.get(chatbotName).get(mutName));
				}
			}
		}
		System.out.println("# Total: " + totalGeneratedMutants + " ----------");
		System.out.println();
		System.out.println("# By mutation operator ----------");
		System.out.println();
		for (String mutName : byMutationOperator.keySet()) {
			System.out.println("# " + mutName + " -> " + byMutationOperator.get(mutName));
		}
		System.out.println();
		System.out.println("# By chatbot ----------");
		System.out.println();
		for (String chatbotName : results.keySet()) {
			int total = 0;
			for (String mutName : results.get(chatbotName).keySet()) {
				total += results.get(chatbotName).get(mutName);
			}
			System.out.println("# " + chatbotName + " -> " + total + " ----------");
			for (String mutName : results.get(chatbotName).keySet()) {
				System.out.println("# " + mutName + " -> " + results.get(chatbotName).get(mutName));
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		generateResultsTxt();
	}
}
