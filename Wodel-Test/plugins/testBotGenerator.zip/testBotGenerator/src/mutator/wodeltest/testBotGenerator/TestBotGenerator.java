package mutator.wodeltest.testBotGenerator;

import es.main.RasaParserGenerator;

public class TestBotGenerator {

	public static void main(String[] args) {
		try {
			RasaParserGenerator.doRasaParser("./zip/vardhaman-freshers-bot.zip", "./data/model/xmi", "1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		RasaParserGenerator.doRasaGenerator("./data/model/xmi/vardhaman-freshers-bot.xmi", "./conga", "1");

	}

}
