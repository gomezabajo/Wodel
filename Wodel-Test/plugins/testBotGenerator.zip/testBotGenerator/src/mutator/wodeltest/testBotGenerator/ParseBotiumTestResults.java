package mutator.wodeltest.testBotGenerator;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;

import java.io.InputStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ParseBotiumTestResults {
	
	public static void parseBotiumTestResults(String fileName){
		try {
			FileInputStream stream = new FileInputStream(fileName);
			JsonReader json = new JsonReader(new InputStreamReader(stream));
			json.setLenient(true);
			while (json.peek() != JsonToken.END_DOCUMENT) {
				JsonObject jsonObject = JsonParser.parseReader(json).getAsJsonObject();
				JsonArray jsonResults = jsonObject.getAsJsonArray("results");
				for (int i = 0; i < jsonResults.size(); i++) {
					JsonObject jsonResult = jsonResults.get(i).getAsJsonObject();
					JsonArray jsonSuites = jsonResult.getAsJsonArray("suites");
					for (int j = 0; j < jsonSuites.size(); j++) {
						JsonObject jsonSuite = jsonSuites.get(j).getAsJsonObject();
						JsonArray jsonTests = jsonSuite.getAsJsonArray("tests");
						for (int k = 0; k < jsonTests.size(); k++) {
							JsonObject jsonTest = jsonTests.get(k).getAsJsonObject();
							JsonElement jsonTitle = jsonTest.get("title");
							String title = jsonTitle.getAsString();
							JsonElement jsonState = jsonTest.get("state");
							String state = jsonState.getAsString();
							JsonPrimitive jsonContext = jsonTest.getAsJsonPrimitive("context");
							String context = jsonContext.getAsString().replace("\\n", "").replace("\n", "");
							if (context.indexOf("\"value\": \"#me:") > 0) {
								context = context.substring(context.indexOf("\"value\": \"#me:") + "\"value\": \"".length(), context.length());
							}
							context = context.substring(0, context.length() > 64 ? 64 : context.length());
							context = context.replace(";", "").replace(":", "").replace("|", "");
							context += "...";
							System.out.println(title);
							System.out.println(state);
							System.out.println(context);

						}
						System.out.println("Total tests: " + jsonTests.size());
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonIOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		if (args.length != 1) {
			return;
		}
		
		if (new File(args[0]).exists() == false) {
			return;
		}
		parseBotiumTestResults(args[0]);
	}
}
