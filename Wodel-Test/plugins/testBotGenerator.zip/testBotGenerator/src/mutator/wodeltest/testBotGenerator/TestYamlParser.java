package mutator.wodeltest.testBotGenerator;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.List;
import java.util.ArrayList;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.comments.CommentLine;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.representer.Representer;
import org.yaml.snakeyaml.nodes.MappingNode;
import org.yaml.snakeyaml.nodes.Node;
import org.yaml.snakeyaml.nodes.NodeTuple;
import org.yaml.snakeyaml.nodes.ScalarNode;
import org.yaml.snakeyaml.nodes.SequenceNode;

public class TestYamlParser {

	private static RasaResult parseRasaResultsYaml(String path) {
		RasaResult rasaResult = null;
		try {
			LoaderOptions loaderOptions = new LoaderOptions();
	        loaderOptions.setProcessComments(true);
			DumperOptions dumperOptions = new DumperOptions();
			dumperOptions.setProcessComments(true);
			dumperOptions.setPrettyFlow(true);
			dumperOptions.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
			Representer represent = new Representer(dumperOptions);
			represent.getPropertyUtils().setSkipMissingProperties(true);
			Yaml yaml = new Yaml(new Constructor(RasaResult.class, loaderOptions), represent, dumperOptions, loaderOptions);
			FileReader reader = new FileReader(path);
			Node node = yaml.compose(reader);
			if (node instanceof MappingNode) {
				MappingNode rootNode = (MappingNode) node; 
				rasaResult = new RasaResult();
				for (NodeTuple tupleNode: rootNode.getValue()) {
					Node keyNode = tupleNode.getKeyNode();
					Node valueNode = tupleNode.getValueNode();
					if (keyNode instanceof ScalarNode) {
						ScalarNode scalarKeyNode = (ScalarNode) keyNode;
						if (valueNode instanceof ScalarNode) {
							ScalarNode scalarValueNode = (ScalarNode) valueNode;
							if (scalarKeyNode.getValue().equals("version")) {
								rasaResult.setVersion(scalarValueNode.getValue());
							}
						}
						if (valueNode instanceof SequenceNode) {
							SequenceNode sequenceValueNode = (SequenceNode) valueNode;
							if (scalarKeyNode.getValue().equals("stories")) {
								List<RasaStory> stories = new ArrayList<RasaStory>();
								for (Node sequenceNode : sequenceValueNode.getValue()) {
									RasaStory story = new RasaStory();
									if (sequenceNode instanceof MappingNode) {
										MappingNode mappingSequenceNode = (MappingNode) sequenceNode;
										for (NodeTuple tupleSequenceNode : mappingSequenceNode.getValue()) {
											Node keySequenceNode = tupleSequenceNode.getKeyNode();
											Node valueSequenceNode = tupleSequenceNode.getValueNode();
											if (keySequenceNode instanceof ScalarNode) {
												ScalarNode scalarKeySequenceNode = (ScalarNode) keySequenceNode;
												if (valueSequenceNode instanceof ScalarNode) {
													ScalarNode scalarValueSequenceNode = (ScalarNode) valueSequenceNode;
													if (scalarKeySequenceNode.getValue().equals("story")) {
														story.setStory(scalarValueSequenceNode.getValue());
													}
												}
												if (valueSequenceNode instanceof SequenceNode) {
													SequenceNode sequenceValueSequenceNode = (SequenceNode) valueSequenceNode;
													if (scalarKeySequenceNode.getValue().equals("steps")) {
														List<RasaStep> steps = new ArrayList<RasaStep>();
														for (Node sequenceSequenceNode : sequenceValueSequenceNode.getValue()) {
															RasaStep step = new RasaStep();
															if (sequenceSequenceNode instanceof MappingNode) {
																MappingNode mappingSequenceSequenceNode = (MappingNode) sequenceSequenceNode;
																for (NodeTuple tupleSequenceSequenceNode : mappingSequenceSequenceNode.getValue()) {
																	Node keySequenceSequenceNode = tupleSequenceSequenceNode.getKeyNode();
																	Node valueSequenceSequenceNode = tupleSequenceSequenceNode.getValueNode();
																	if (keySequenceSequenceNode instanceof ScalarNode) {
																		ScalarNode scalarKeySequenceSequenceNode = (ScalarNode) keySequenceSequenceNode;
																		if (valueSequenceSequenceNode instanceof ScalarNode) {
																			ScalarNode scalarValueSequenceSequenceNode = (ScalarNode) valueSequenceSequenceNode;
																			if (scalarKeySequenceSequenceNode.getValue().equals("intent")) {
																				step.setIntent(scalarValueSequenceSequenceNode.getValue());
																			}
																			if (scalarKeySequenceSequenceNode.getValue().equals("action")) {
																				List<CommentLine> comments = scalarValueSequenceSequenceNode.getInLineComments();
																				if (comments != null) {
																					for (CommentLine comment : comments) {
																						step.addComment(comment.getValue());
																					}
																				}
																				step.setAction(scalarValueSequenceSequenceNode.getValue());
																			}
																		}
																	}
																}
															}
															steps.add(step);
														}
														story.setSteps(steps);
													}
												}
											}
										}
									}
									stories.add(story);
								}
								rasaResult.setStories(stories);
							}
						}
					}
				}
			}
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rasaResult;
	}

	public static void main(String[] args) {
		String folderName = "./yaml";
		String successfulTestStoriesPath = folderName + "/successful_test_stories.yml";
		String storiesWithWarningsPath = folderName + "/stories_with_warnings.yml";
		String failedTestStoriesPath = folderName + "/failed_test_stories.yml";
		RasaResult successfulTestStoriesResult = parseRasaResultsYaml(successfulTestStoriesPath);
		System.out.println(successfulTestStoriesResult);
		RasaResult storiesWithWarningsResult = parseRasaResultsYaml(storiesWithWarningsPath);
		System.out.println(storiesWithWarningsResult);
		RasaResult failedTestStoriesResult = parseRasaResultsYaml(failedTestStoriesPath);
		System.out.println(failedTestStoriesResult);
	}
}
