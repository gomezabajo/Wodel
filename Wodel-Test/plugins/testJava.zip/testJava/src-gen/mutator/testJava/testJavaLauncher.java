package mutator.testJava;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.AbstractMap.SimpleEntry;
import org.eclipse.core.resources.IProject;
import exceptions.*;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EPackage;
import mutator.testJavaAO.testJavaAO;
import mutator.testJavaAP.testJavaAP;
import mutator.testJavaASO.testJavaASO;
import mutator.testJavaCO.testJavaCO;
import mutator.testJavaCOD.testJavaCOD;
import mutator.testJavaDLM.testJavaDLM;
import mutator.testJavaIN.testJavaIN;
import mutator.testJavaLO.testJavaLO;
import mutator.testJavaNLS.testJavaNLS;
import mutator.testJavaRest.testJavaRest;
import mutator.testJavaRO.testJavaRO;
import mutator.testJavaSO.testJavaSO;
import mutator.testJavaUCOD.testJavaUCOD;
import manager.IMutatorExecutor;
import manager.IWodelTest;
import manager.ModelManager;
import manager.MutatorUtils;
import manager.MutatorUtils.MutationResults;

public class testJavaLauncher implements IMutatorExecutor {
	public MutationResults execute(int maxAttempts, int numMutants, boolean registry, boolean metrics,
			boolean debugMetrics, String[] blockNames, IProject project, IProgressMonitor monitor, boolean serialize,
			Object testObject, TreeMap<String, List<String>> classes)
			throws ReferenceNonExistingException, WrongAttributeTypeException, MaxSmallerThanMinException,
			AbstractCreationException, ObjectNoTargetableException, ObjectNotContainedException,
			MetaModelNotFoundException, ModelNotFoundException, IOException {
		IWodelTest test = testObject != null ? (IWodelTest) testObject : null;
		String ecoreURI = "/testJava/data/model/java.ecore";
		List<EPackage> packages = ModelManager.loadMetaModel(ecoreURI, this.getClass());
		boolean isRegistered = ModelManager.isRegistered(packages);
		Map<String, EPackage> registeredPackages = new HashMap<String, EPackage>();
		if (isRegistered == true) {
			registeredPackages = ModelManager.unregisterMetaModel(packages);
		}
		MutationResults mutationResults = new MutationResults();
		MutatorUtils muttestJavaAO = new testJavaAO();
		MutationResults resultstestJavaAO = muttestJavaAO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaAO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaAO.numMutantsGenerated;
		if (resultstestJavaAO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaAO.mutatorsApplied);
		}
		MutatorUtils muttestJavaAP = new testJavaAP();
		MutationResults resultstestJavaAP = muttestJavaAP.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaAP.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaAP.numMutantsGenerated;
		if (resultstestJavaAP.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaAP.mutatorsApplied);
		}
		MutatorUtils muttestJavaASO = new testJavaASO();
		MutationResults resultstestJavaASO = muttestJavaASO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaASO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaASO.numMutantsGenerated;
		if (resultstestJavaASO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaASO.mutatorsApplied);
		}
		MutatorUtils muttestJavaCO = new testJavaCO();
		MutationResults resultstestJavaCO = muttestJavaCO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaCO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaCO.numMutantsGenerated;
		if (resultstestJavaCO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaCO.mutatorsApplied);
		}
		MutatorUtils muttestJavaCOD = new testJavaCOD();
		MutationResults resultstestJavaCOD = muttestJavaCOD.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaCOD.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaCOD.numMutantsGenerated;
		if (resultstestJavaCOD.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaCOD.mutatorsApplied);
		}
		MutatorUtils muttestJavaDLM = new testJavaDLM();
		MutationResults resultstestJavaDLM = muttestJavaDLM.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaDLM.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaDLM.numMutantsGenerated;
		if (resultstestJavaDLM.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaDLM.mutatorsApplied);
		}
		MutatorUtils muttestJavaIN = new testJavaIN();
		MutationResults resultstestJavaIN = muttestJavaIN.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaIN.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaIN.numMutantsGenerated;
		if (resultstestJavaIN.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaIN.mutatorsApplied);
		}
		MutatorUtils muttestJavaLO = new testJavaLO();
		MutationResults resultstestJavaLO = muttestJavaLO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaLO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaLO.numMutantsGenerated;
		if (resultstestJavaLO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaLO.mutatorsApplied);
		}
		MutatorUtils muttestJavaNLS = new testJavaNLS();
		MutationResults resultstestJavaNLS = muttestJavaNLS.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaNLS.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaNLS.numMutantsGenerated;
		if (resultstestJavaNLS.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaNLS.mutatorsApplied);
		}
		MutatorUtils muttestJavaRest = new testJavaRest();
		MutationResults resultstestJavaRest = muttestJavaRest.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaRest.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaRest.numMutantsGenerated;
		if (resultstestJavaRest.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaRest.mutatorsApplied);
		}
		MutatorUtils muttestJavaRO = new testJavaRO();
		MutationResults resultstestJavaRO = muttestJavaRO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaRO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaRO.numMutantsGenerated;
		if (resultstestJavaRO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaRO.mutatorsApplied);
		}
		MutatorUtils muttestJavaSO = new testJavaSO();
		MutationResults resultstestJavaSO = muttestJavaSO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaSO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaSO.numMutantsGenerated;
		if (resultstestJavaSO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaSO.mutatorsApplied);
		}
		MutatorUtils muttestJavaUCOD = new testJavaUCOD();
		MutationResults resultstestJavaUCOD = muttestJavaUCOD.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaUCOD.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaUCOD.numMutantsGenerated;
		if (resultstestJavaUCOD.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaUCOD.mutatorsApplied);
		}
		if (isRegistered == true) {
			ModelManager.registerMetaModel(registeredPackages);
		}
		return mutationResults;
	}
}
