package mutator.testJava;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.AbstractMap.SimpleEntry;
import org.eclipse.core.resources.IProject;
import exceptions.*;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EPackage;
import mutator.testJavaAO.testJavaAO;
import mutator.testJavaASO.testJavaASO;
import mutator.testJavaCO.testJavaCO;
import mutator.testJavaLO.testJavaLO;
import mutator.testJavaOther.testJavaOther;
import mutator.testJavaRest.testJavaRest;
import mutator.testJavaRO.testJavaRO;
import mutator.testJavaSO.testJavaSO;
import manager.IMutatorExecutor;
import manager.IWodelTest;
import manager.ModelManager;
import manager.MutatorUtils;
import manager.MutatorUtils.MutationResults;

public class testJavaLauncher implements IMutatorExecutor {
	public MutationResults execute(int maxAttempts, int numMutants, boolean registry, boolean metrics,
			boolean debugMetrics, String[] blockNames, IProject project, IProgressMonitor monitor, boolean serialize,
			Object testObject, TreeMap<String, List<String>> classes)
			throws ReferenceNonExistingException, WrongAttributeTypeException, MaxSmallerThanMinException,
			AbstractCreationException, ObjectNoTargetableException, ObjectNotContainedException,
			MetaModelNotFoundException, ModelNotFoundException, IOException {
		IWodelTest test = testObject != null ? (IWodelTest) testObject : null;
		String ecoreURI = "C:/eclipse/workspace/testJava/data/model/java.ecore";
		List<EPackage> packages = ModelManager.loadMetaModel(ecoreURI);
		boolean isRegistered = ModelManager.isRegistered(packages);
		Map<String, EPackage> registeredPackages = new HashMap<String, EPackage>();
		if (isRegistered == true) {
			registeredPackages = ModelManager.unregisterMetaModel(packages);
		}
		MutationResults mutationResults = new MutationResults();
		MutatorUtils muttestJavaAO = new testJavaAO();
		MutationResults resultstestJavaAO = muttestJavaAO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaAO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaAO.numMutantsGenerated;
		if (resultstestJavaAO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaAO.mutatorsApplied);
		}
		MutatorUtils muttestJavaASO = new testJavaASO();
		MutationResults resultstestJavaASO = muttestJavaASO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaASO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaASO.numMutantsGenerated;
		if (resultstestJavaASO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaASO.mutatorsApplied);
		}
		MutatorUtils muttestJavaCO = new testJavaCO();
		MutationResults resultstestJavaCO = muttestJavaCO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaCO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaCO.numMutantsGenerated;
		if (resultstestJavaCO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaCO.mutatorsApplied);
		}
		MutatorUtils muttestJavaLO = new testJavaLO();
		MutationResults resultstestJavaLO = muttestJavaLO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaLO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaLO.numMutantsGenerated;
		if (resultstestJavaLO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaLO.mutatorsApplied);
		}
		MutatorUtils muttestJavaOther = new testJavaOther();
		MutationResults resultstestJavaOther = muttestJavaOther.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaOther.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaOther.numMutantsGenerated;
		if (resultstestJavaOther.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaOther.mutatorsApplied);
		}
		MutatorUtils muttestJavaRest = new testJavaRest();
		MutationResults resultstestJavaRest = muttestJavaRest.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaRest.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaRest.numMutantsGenerated;
		if (resultstestJavaRest.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaRest.mutatorsApplied);
		}
		MutatorUtils muttestJavaRO = new testJavaRO();
		MutationResults resultstestJavaRO = muttestJavaRO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaRO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaRO.numMutantsGenerated;
		if (resultstestJavaRO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaRO.mutatorsApplied);
		}
		MutatorUtils muttestJavaSO = new testJavaSO();
		MutationResults resultstestJavaSO = muttestJavaSO.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestJavaSO.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestJavaSO.numMutantsGenerated;
		if (resultstestJavaSO.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestJavaSO.mutatorsApplied);
		}
		if (isRegistered == true) {
			ModelManager.registerMetaModel(registeredPackages);
		}
		return mutationResults;
	}
}
