package mutator.wodeltest.testBotGenerator;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class BotiumJSONGenerator {

	public static void main(String[] args) {
		PrintWriter jsonwriter = null;
		if (args.length < 4) {
			return;
		}
		try {
			jsonwriter = new PrintWriter(args[0], "UTF-8");
			jsonwriter.println("{");
			jsonwriter.println("  \"botium\": {");
			jsonwriter.println("    \"Capabilities\": {");
			jsonwriter.println("      \"PROJECTNAME\": \"" + args[1] + "-" + args[2].replace("/", "-") + "\",");
			jsonwriter.println("      \"CONTAINERMODE\": \"rasa\",");
			jsonwriter.println("      \"RASA_ENDPOINT_URL\": \"http://127.0.0.1:" + args[3] + "\",");
			jsonwriter.println("      \"RASA_MODE\": \"REST_INPUT\"");
			jsonwriter.println("    }");
			jsonwriter.println("  }");
			jsonwriter.println("}");
			jsonwriter.close();
		} catch (UnsupportedEncodingException e) {
			return;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
