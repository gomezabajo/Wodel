package mutator.testATL;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.AbstractMap.SimpleEntry;
import org.eclipse.core.resources.IProject;
import exceptions.*;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EPackage;
import mutator.testATLB.testATLB;
import mutator.testATLF.testATLF;
import mutator.testATLIPE.testATLIPE;
import mutator.testATLMR.testATLMR;
import mutator.testATLOPE.testATLOPE;
import manager.IMutatorExecutor;
import manager.IWodelTest;
import manager.ModelManager;
import manager.MutatorUtils;
import manager.MutatorUtils.MutationResults;

public class testATLLauncher implements IMutatorExecutor {
	public MutationResults execute(int maxAttempts, int numMutants, boolean registry, boolean metrics,
			boolean debugMetrics, String[] blockNames, IProject project, IProgressMonitor monitor, boolean serialize,
			Object testObject, TreeMap<String, List<String>> classes)
			throws ReferenceNonExistingException, WrongAttributeTypeException, MaxSmallerThanMinException,
			AbstractCreationException, ObjectNoTargetableException, ObjectNotContainedException,
			MetaModelNotFoundException, ModelNotFoundException, IOException {
		IWodelTest test = testObject != null ? (IWodelTest) testObject : null;
		String ecoreURI = "C:/eclipse/workspace/testATL/data/model/ATL.ecore";
		List<EPackage> packages = ModelManager.loadMetaModel(ecoreURI);
		boolean isRegistered = ModelManager.isRegistered(packages);
		Map<String, EPackage> registeredPackages = new HashMap<String, EPackage>();
		if (isRegistered == true) {
			registeredPackages = ModelManager.unregisterMetaModel(packages);
		}
		MutationResults mutationResults = new MutationResults();
		MutatorUtils muttestATLB = new testATLB();
		MutationResults resultstestATLB = muttestATLB.execute(maxAttempts, numMutants, registry, metrics, debugMetrics,
				packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestATLB.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestATLB.numMutantsGenerated;
		if (resultstestATLB.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestATLB.mutatorsApplied);
		}
		MutatorUtils muttestATLF = new testATLF();
		MutationResults resultstestATLF = muttestATLF.execute(maxAttempts, numMutants, registry, metrics, debugMetrics,
				packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestATLF.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestATLF.numMutantsGenerated;
		if (resultstestATLF.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestATLF.mutatorsApplied);
		}
		MutatorUtils muttestATLIPE = new testATLIPE();
		MutationResults resultstestATLIPE = muttestATLIPE.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestATLIPE.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestATLIPE.numMutantsGenerated;
		if (resultstestATLIPE.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestATLIPE.mutatorsApplied);
		}
		MutatorUtils muttestATLMR = new testATLMR();
		MutationResults resultstestATLMR = muttestATLMR.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestATLMR.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestATLMR.numMutantsGenerated;
		if (resultstestATLMR.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestATLMR.mutatorsApplied);
		}
		MutatorUtils muttestATLOPE = new testATLOPE();
		MutationResults resultstestATLOPE = muttestATLOPE.execute(maxAttempts, numMutants, registry, metrics,
				debugMetrics, packages, registeredPackages, blockNames, project, monitor, serialize, test, classes);
		mutationResults.numMutatorsApplied += resultstestATLOPE.numMutatorsApplied;
		mutationResults.numMutantsGenerated += resultstestATLOPE.numMutantsGenerated;
		if (resultstestATLOPE.mutatorsApplied != null) {
			if (mutationResults.mutatorsApplied == null) {
				mutationResults.mutatorsApplied = new ArrayList<String>();
			}
			mutationResults.mutatorsApplied.addAll(resultstestATLOPE.mutatorsApplied);
		}
		if (isRegistered == true) {
			ModelManager.registerMetaModel(registeredPackages);
		}
		return mutationResults;
	}
}
