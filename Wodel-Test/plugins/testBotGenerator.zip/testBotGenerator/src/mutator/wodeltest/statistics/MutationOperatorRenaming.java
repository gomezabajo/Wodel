package mutator.wodeltest.statistics;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class MutationOperatorRenaming {

	private static final String projectPath = GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().substring(0, GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().lastIndexOf("/")).substring(0, GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().substring(0, GenerateResultsTxt.class.getProtectionDomain().getCodeSource().getLocation().toString().lastIndexOf("/")).lastIndexOf("/")).replace("file:/", "");
	private static final String projectName = projectPath.substring(projectPath.lastIndexOf("/") + 1, projectPath.length());
	private static final String outputPath = projectPath + "/data/backup/exhaustive-new";
	
	private static void mutationOperatorRenaming() {
		try {
			File outputFolder = new File(outputPath);
			if (outputFolder.exists() && outputFolder.isDirectory()) {
				File[] chatbotFolders = outputFolder.listFiles();
				if (chatbotFolders.length > 0) {
					for (File chatbotFolder : chatbotFolders) {
						if (chatbotFolder.exists() && chatbotFolder.isDirectory()) {
							File[] mutOperatorFolders = chatbotFolder.listFiles();
							if (mutOperatorFolders.length > 0) {
								for (File mutOperatorFolder : mutOperatorFolders) {
									if (mutOperatorFolder.exists() && mutOperatorFolder.isDirectory()) {
										switch (mutOperatorFolder.getName()) {
										case "fbintent" :
											String oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											String newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dfi");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "flow1" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/da");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "flow2" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dcb");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "flow3" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/jcs");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp1max" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dp_max");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp1min" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dp_min");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp2" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dpwp");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp3" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dpwl");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp4" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/rip");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp5max" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/k2p_max");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp5min" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/k2p_min");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp6max" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/mp_max");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "tp6min" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/mp_min");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "param1" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dpr");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "param2" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dpp");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "param3" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/spo");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "regexp" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/cre");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "jcs" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dcs");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										case "dl" :
											oldPath = mutOperatorFolder.getPath().replace("\\", "/");
											newPath = oldPath.replace("/" + mutOperatorFolder.getName(), "/dle");
											Files.move(Paths.get(oldPath), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
											break;
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		mutationOperatorRenaming();
	}

}
