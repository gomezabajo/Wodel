This distribution includes the Mozilla Rhino 1.5 release 4.1 binary
distribution without code modifications.
You can also get that distribution from the following URL:
ftp://ftp.mozilla.org/pub/js/
Source code for Rhino is available on Mozilla web site:
http://www.mozilla.org/rhino
Rhino is licensed under the NPL (Netscape Public License) which 
is in the LICENSE.js.txt file

