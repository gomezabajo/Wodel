# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message("Hello World!")
#
#         return []
from typing import Dict, Text, Any, List, Union, Optional

from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Action
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT
import requests

		
	
	
	
class action_carousels_empty (Action):
	def name(self) -> Text:
		return "action_carousels_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
class utter_Faculty_details_it_empty (Action):
	def name(self) -> Text:
		return "action_utter_Faculty_details_it_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
	
	
class action_Placements_empty (Action):
	def name(self) -> Text:
		return "action_Placements_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_Transportation_empty (Action):
	def name(self) -> Text:
		return "action_Transportation_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
class action_Faculty_details_mech_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_mech_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
class action_Academic_Regulations_empty (Action):
	def name(self) -> Text:
		return "action_Academic_Regulations_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
class action_Notifications_empty (Action):
	def name(self) -> Text:
		return "action_Notifications_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_Sports_empty (Action):
	def name(self) -> Text:
		return "action_Sports_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
class action_Faculty_details_civil_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_civil_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
	
class action_Labs_empty (Action):
	def name(self) -> Text:
		return "action_Labs_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_faculty_details_empty (Action):
	def name(self) -> Text:
		return "action_faculty_details_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_Autonomy_Governance_empty (Action):
	def name(self) -> Text:
		return "action_Autonomy_Governance_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_Library_empty (Action):
	def name(self) -> Text:
		return "action_Library_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_admission_form_empty (Action):
	def name(self) -> Text:
		return "action_admission_form_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_Faculty_details_bsh_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_bsh_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_timetable_empty (Action):
	def name(self) -> Text:
		return "action_timetable_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_power_and_industrial_drives_empty (Action):
	def name(self) -> Text:
		return "action_power_and_industrial_drives_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
	
	
	
	
	
	
	
class action_Faculty_details_CSE_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_CSE_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_PG_Programs_empty (Action):
	def name(self) -> Text:
		return "action_PG_Programs_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
class action_Lecture_capturing_system_empty (Action):
	def name(self) -> Text:
		return "action_Lecture_capturing_system_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_online_payments_empty (Action):
	def name(self) -> Text:
		return "action_online_payments_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_Faculty_details_eee_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_eee_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
class action_Faculty_details_it_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_it_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
	
	
	
	
	
class action_hello_world_empty (Action):
	def name(self) -> Text:
		return "action_hello_world_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_Exam_Notifications_empty (Action):
	def name(self) -> Text:
		return "action_Exam_Notifications_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
class action_student_parent_login_empty (Action):
	def name(self) -> Text:
		return "action_student_parent_login_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_academic_calendar_empty (Action):
	def name(self) -> Text:
		return "action_academic_calendar_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_results_empty (Action):
	def name(self) -> Text:
		return "action_results_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
class action_Environmental_empty (Action):
	def name(self) -> Text:
		return "action_Environmental_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_Cyber_Security_empty (Action):
	def name(self) -> Text:
		return "action_Cyber_Security_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_Faculty_details_ece_empty (Action):
	def name(self) -> Text:
		return "action_Faculty_details_ece_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_hod_details_empty (Action):
	def name(self) -> Text:
		return "action_hod_details_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
class action_360view_empty (Action):
	def name(self) -> Text:
		return "action_360view_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
class action_LAN_Based_courses_empty (Action):
	def name(self) -> Text:
		return "action_LAN_Based_courses_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
class action_Thermal_empty (Action):
	def name(self) -> Text:
		return "action_Thermal_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
class action_VLSI_and_embedded_systems_design_empty (Action):
	def name(self) -> Text:
		return "action_VLSI_and_embedded_systems_design_empty"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
	
	
class DefaultEmptyAction (Action):
	def name(self) -> Text:
		return "action_DefaultEmptyAction"
	
	def run(self, dispatcher: CollectingDispatcher,
			tracker: Tracker,
			domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
		return []  
	
	
